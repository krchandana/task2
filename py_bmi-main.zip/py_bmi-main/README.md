# Py_bmi
A Python module for Checking your bmi

## Installation
```
pip install Py-bmi
```

### Usage
```py
from py_bmi import bmi
```

### Example of using
```py
from py_bmi import bmi
weight = 85
height = 1.4
print(bmi(weight,height))
# >> OH.. Noo.. You are Obesity
#The First Variable Must Be Weight In Kilograms 
#The Second Variable Must Be Height In Meters 
#Both Are Must Be Intergers 
```
---


## Special Thanks

[Fayas Noushad](https://github.com/FayasNoushad) & [Lokaman](https://github.com/lntechnical2) For Helping Me

---
